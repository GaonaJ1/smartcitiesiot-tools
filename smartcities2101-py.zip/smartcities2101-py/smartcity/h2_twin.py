"""Green H₂ Power Simulator — integrated digital twin.

Port of ``digital-twin.html``: hybrid solar+wind generation → PEM electrolyzer → H₂
storage, an IoT sensor node (temperature / light / LED), a DSP lab (AM modulation,
envelope detection, radar clean-up) and an FFT anomaly detector.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

LEVELS = {0: "very_low", 1: "low", 2: "medium", 3: "high"}


# --------------------------------------------------------------------------- plant model
@dataclass
class PlantState:
    hour: int = 0
    efficiency: float = 0.72
    degradation: float = 0.00002
    h2_rate: float = 0.0
    h2_total: float = 0.0
    storage: float = 0.0
    storage_cap: float = 2000.0
    op_hours: int = 0
    temperature: float = 25.0
    light: float = 5.0
    led_on: bool = False
    iot_class: str = "medium"
    stack_depth: int = 0


def solar_wind_power(hour: float, rng: np.random.Generator) -> float:
    """kW from a diurnal solar curve plus stochastic wind."""
    h = hour % 24
    solar = 400 * math.sin(math.pi * (h - 6) / 12) if 6 <= h <= 18 else 0.0
    wind = 100 + rng.random() * 250 + (rng.random() - 0.5) * 60
    return max(0.0, solar + wind)


def electrolyzer_step(s: PlantState, power: float) -> None:
    """Advance the PEM electrolyzer one hour (500 kW cap, efficiency degrades with use)."""
    s.op_hours += 1
    s.efficiency = max(0.72 - s.degradation * s.op_hours, 0.55)
    used = min(500.0, max(0.0, power))
    s.h2_rate = s.efficiency * used / 33.33            # kg/h (33.33 kWh per kg H₂)
    s.h2_total += s.h2_rate
    s.storage += min(s.h2_rate, s.storage_cap - s.storage)


def iot_step(s: PlantState, hour: float, rng: np.random.Generator) -> None:
    h = hour % 24
    diurnal = 5 * math.sin(math.pi * (h - 6) / 12)
    s.temperature = 25 + diurnal + (rng.random() - 0.5)
    if 6 <= h <= 18:
        s.light = 8 * math.sin(math.pi * (h - 6) / 12) + (rng.random() - 0.5) * 0.8
    else:
        s.light = 0.3 + rng.random() * 0.4
    s.light = max(0.0, s.light)
    s.led_on = s.temperature > 30 or s.light < 3
    s.iot_class = LEVELS[min(3, max(0, int(s.light // 2.5)))]
    s.stack_depth += 1


def run_plant(hours: int = 72, seed: int = 42) -> pd.DataFrame:
    """Simulate ``hours`` hourly steps and return a tidy DataFrame."""
    rng = np.random.default_rng(seed)
    s = PlantState()
    rows = []
    for hr in range(hours):
        s.hour = hr
        power = solar_wind_power(hr, rng)
        electrolyzer_step(s, power)
        iot_step(s, hr, rng)
        rows.append(
            dict(hour=hr, power_kw=power, efficiency=s.efficiency, h2_rate_kg_h=s.h2_rate,
                 h2_total_kg=s.h2_total, storage_kg=s.storage, temperature_c=s.temperature,
                 light=s.light, led_on=s.led_on, iot_class=s.iot_class)
        )
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- DSP lab
def moving_average(x: np.ndarray, window: int = 40) -> np.ndarray:
    """Causal moving average over the last ``window + 1`` samples (as in the JS)."""
    c = np.cumsum(np.insert(x, 0, 0.0))
    idx = np.arange(len(x))
    lo = np.maximum(0, idx - window)
    return (c[idx + 1] - c[lo]) / (idx - lo + 1)


def rms(x: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.square(x))))


def generate_dsp(rng: np.random.Generator, fs: int = 2000, dur: float = 0.25,
                 fm: float = 10, fc: float = 200, sigma: float = 0.15) -> dict:
    """AM demodulation (rectify + moving average) and radar DC-removal + gating."""
    n = int(fs * dur)
    t = np.arange(n) / fs
    mod, car = np.sin(2 * np.pi * fm * t), np.sin(2 * np.pi * fc * t)
    am = (1 + mod) * car
    noisy = am + sigma * (rng.uniform(-1, 1, n) + rng.uniform(-1, 1, n))
    rec = moving_average(np.abs(noisy), 40)

    radar_raw = np.sin(2 * np.pi * 80 * t)
    radar_proc = radar_raw - radar_raw.mean()
    gated = np.where(np.abs(radar_proc * 2) > 0.2, radar_proc * 2, 0.0)
    return dict(t=t, mod=mod, car=car, am=noisy, rec=rec, radar_raw=radar_raw,
                radar_proc=radar_proc, gated=gated, rms_noisy=rms(noisy), rms_rec=rms(rec),
                rms_radar=rms(radar_proc), rms_final=rms(gated))


# --------------------------------------------------------------------------- FFT
def fft_radix2(x: np.ndarray) -> np.ndarray:
    """Recursive radix-2 Cooley–Tukey FFT (ported from the page; N must be a power of 2).

    ``np.fft.fft`` is used in the UI; this is kept so the port is faithful and testable.
    """
    n = len(x)
    if n <= 1:
        return np.asarray(x, dtype=complex)
    even, odd = fft_radix2(x[0::2]), fft_radix2(x[1::2])
    tw = np.exp(-2j * np.pi * np.arange(n // 2) / n) * odd
    return np.concatenate([even + tw, even - tw])


def generate_fft(hour: int, rng: np.random.Generator, n: int = 256, sr: int = 100,
                 anomaly: bool | None = None) -> dict:
    """5 Hz + 12 Hz machine signature; a 35 Hz fault tone appears when ``hour % 30 > 20``."""
    anomaly_on = (hour % 30) > 20 if anomaly is None else anomaly
    t = np.arange(n) / sr
    sig = np.sin(2 * np.pi * 5 * t) + 0.3 * np.sin(2 * np.pi * 12 * t)
    if anomaly_on:
        sig += 0.7 * np.sin(2 * np.pi * 35 * t)
    sig += (rng.random(n) - 0.5) * 0.2
    spec = np.fft.fft(sig)[: n // 2]
    mags = np.abs(spec) * 2 / n
    freqs = np.arange(n // 2) * sr / n
    dom = 1 + int(np.argmax(mags[1:]))
    peaks = [(float(f), float(m), bool(f > 15)) for f, m in zip(freqs[1:], mags[1:]) if m > 0.08]
    anomalies = [p for p in peaks if p[2]]
    return dict(sig=sig, mags=mags, freqs=freqs, dom_freq=float(freqs[dom]), dom_mag=float(mags[dom]),
                peaks=peaks, anomalies=anomalies, alert=bool(anomalies), anomaly_injected=anomaly_on)


# --------------------------------------------------------------------------- plant layout (3D)
# Offsets are in the original degrees (lon, lat); 1° ≈ 111 km, so ×111_000 gives metres (N/E).
M_PER_DEG = 111_000.0

# name, (dLon, dLat, height_m), kind, colour
COMPONENTS = [
    ("PEM ELECTROLYZER", (0.0, 0.0, 15), "box", "#00e5ff"),
    ("MASTER CONTROL", (-0.004, -0.006, 5), "box", "#2f4f4f"),
    ("COOLING", (0.004, 0.006, 10), "box", "#1e90ff"),
    ("C-1", (0.008, 0.003, 8), "cyl", "#c0c0c0"),
    ("C-2", (0.008, 0.0, 8), "cyl", "#c0c0c0"),
    ("C-3", (0.008, -0.003, 8), "cyl", "#c0c0c0"),
    ("PURIFICATION", (0.012, -0.005, 20), "box", "#f8f8ff"),
    ("H₂ TANK A", (0.02, 0.006, 20), "tank", "#32cd32"),
    ("H₂ TANK B", (0.02, -0.004, 20), "tank", "#32cd32"),
    ("IoT SENSORS", (-0.006, 0.009, 6), "box", "#b8860b"),
    ("DSP SIGNAL LAB", (0.014, 0.009, 8), "box", "#b388ff"),
    ("FFT ANALYSIS", (-0.006, -0.01, 18), "box", "#008b8b"),
]
TURBINES = [(-0.013, 0.008), (-0.013, -0.002), (-0.013, -0.012)]
FLOWS = [  # (start, end, colour): energy / H₂ / data paths
    ((-0.013, 0, 10), (-0.004, -0.006, 10), "#ffff00"),
    ((-0.004, -0.006, 10), (0, 0, 10), "#00ffff"),
    ((0, 0, 10), (0.004, 0.006, 10), "#00ffff"),
    ((0.004, 0.006, 10), (0.008, 0, 10), "#00ffff"),
    ((0.008, 0, 10), (0.012, -0.005, 10), "#00ffff"),
    ((0.012, -0.005, 10), (0.02, 0, 10), "#00ffff"),
    ((-0.006, 0.009, 6), (-0.004, -0.006, 8), "#ffff00"),
    ((0.014, 0.009, 8), (-0.004, -0.006, 8), "#b388ff"),
    ((-0.006, -0.01, 10), (-0.004, -0.006, 8), "#008b8b"),
]


def to_local_m(dlon: float, dlat: float) -> tuple[float, float]:
    """Degree offsets → local east/north metres."""
    return dlon * M_PER_DEG, dlat * M_PER_DEG
