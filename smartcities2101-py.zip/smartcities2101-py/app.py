"""Smart City Platform — home hub. Run with:  streamlit run app.py"""

import streamlit as st

from smartcity import ui

ui.setup("Smart City Platform", "IoT · Telemetry · Urban Intelligence",
         "Simulations, digital twins and 3D models — 100% Python (NumPy · Plotly · Streamlit).", icon="🏙️")

CARDS = [
    ("pages/1_Overview.py", "Overview", "IoT sensors overview: key stats and the telemetry topics flowing through the platform."),
    ("pages/2_Article.py", "Article", "650-word field report on IoT sensors for smart cities."),
    ("pages/3_Sensors.py", "Sensor Categories", "Six sensor families and the five-layer edge-to-cloud stack."),
    ("pages/4_Digital_Twin.py", "Green H₂ Digital Twin", "Solar+wind → PEM electrolyzer → H₂ storage, with an IoT node, DSP lab and FFT anomaly detector."),
    ("pages/5_Breadboard_3D.py", "RPi Linux Monitor", "Live Raspberry Pi telemetry on a 3D breadboard: CPU, thermals, GPIO, I²C, services."),
    ("pages/6_Ops_Dashboard.py", "Saltillo Ops Console", "MQTT-style sensor mesh, event feed, gateway health and 50 field sensors."),
    ("pages/7_Robotic_Arm.py", "Robotic Arm · Kinematics", "Quaternion/slerp pick-and-place state machine on a wireframe arm."),
]

cols = st.columns(3)
for i, (path, title, desc) in enumerate(CARDS):
    with cols[i % 3]:
        st.markdown(ui.card(title, desc), unsafe_allow_html=True)
        st.page_link(path, label=f"Open {title} →")
        st.write("")
