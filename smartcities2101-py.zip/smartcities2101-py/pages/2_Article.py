import streamlit as st

from smartcity import content, ui

ui.setup("IoT Sensors for Smart Cities", "Research · IoT Infrastructure", icon="📰", wide=False)
st.markdown(content.ARTICLE_MD.split("\n", 4)[-1].lstrip())   # title is already in the header
st.divider()
a, b = st.columns(2)
a.page_link("pages/3_Sensors.py", label="Up next → Sensor Categories")
b.page_link("app.py", label="← Back Home")
