# Smart City Platform — Python edition

A pure-Python port of the original Flask + HTML/JS/Cesium site (`smartcities2101`).
Every page that used to be hand-written HTML/JavaScript is now Python: the simulation
logic lives in importable, tested modules and the UI is a Streamlit app with Plotly 3D.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py        # http://localhost:8501
pytest -q                   # 21 tests: simulations + every page renders
```

## What was converted

| Original page (HTML/JS) | Python module | Streamlit page |
|---|---|---|
| `templates/overview.html`, `article.html`, `sensors.html` (Jinja2) | `smartcity/content.py` | `1_Overview`, `2_Article`, `3_Sensors` |
| `digital-twin.html` — Green H₂ twin (Cesium + canvas) | `smartcity/h2_twin.py` | `4_Digital_Twin` |
| `breadboard-3d.html` — RPi monitor (Cesium) | `smartcity/rpi_monitor.py` | `5_Breadboard_3D` |
| `dashboard.html` — Saltillo ops console (React + Cesium) | `smartcity/sensor_mesh.py` | `6_Ops_Dashboard` |
| `robotic-arm-3d.html` — arm kinematics (three.js) | `smartcity/robot_arm.py`, `geometry.py` | `7_Robotic_Arm` |
| `hub.html` + `flask_app.py` routes | — | `app.py` (home hub) |

Plotting for all pages: `smartcity/figures.py`.

## Layout

```
app.py                  home hub
pages/                  one Streamlit page per original page
smartcity/              simulations, geometry, Plotly figures, content
smartcity/models/       robot_arm.obj (data, extracted from the original page)
tests/                  pytest: simulation maths + headless page smoke tests
```

## Notes on fidelity

- Simulation rules (random walks, thresholds, electrolyzer model, FFT anomaly rule,
  state machine timings, deterministic Odessa sensor placement) are ported 1:1.
- Cesium globe visuals were replaced by Plotly 3D scenes in local metres and an
  OpenStreetMap-based map; the arm animation is precomputed in Python and played by Plotly.
- Randomness is seeded, so runs are reproducible.
