"""Robotic arm — kinematics + pick-and-place state machine.

Port of ``robotic-arm-3d.html``. The original loaded an embedded Wavefront OBJ into
three.js and drove the base with quaternion integration, slerp and cubic easing. This
module keeps the same maths in NumPy and renders the wireframe with Plotly.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from .geometry import (
    IDENTITY,
    ease_in_out_cubic,
    q_from_axis_angle,
    q_from_euler_yxz,
    q_mul,
    q_normalize,
    q_slerp,
    q_to_matrix,
    q_yaw_yxz,
)

MODEL_PATH = Path(__file__).parent / "models" / "robot_arm.obj"
SCREW_COUNT = 6
SCREW_RADIUS = 1.15
STATUS_ES = {
    "idle": "En reposo — rotación libre",
    "aiming": "Girando hacia tornillo…",
    "dipping": "Bajando a recoger…",
    "grabbed": "Sujetando tornillo…",
    "lifting": "Levantando…",
    "returning": "Regresando a reposo…",
}


# --------------------------------------------------------------------------- model loading
def load_obj(path: Path = MODEL_PATH):
    """Parse a minimal Wavefront OBJ → (vertices[N,3], faces[list of index lists])."""
    verts, faces = [], []
    for line in Path(path).read_text().splitlines():
        parts = line.split()
        if not parts:
            continue
        if parts[0] == "v":
            verts.append([float(p) for p in parts[1:4]])
        elif parts[0] == "f":
            faces.append([int(p.split("/")[0]) - 1 for p in parts[1:]])
    return np.array(verts), faces


def outline_edges(faces) -> np.ndarray:
    """Unique polygon-outline edges (equivalent to three.js ``EdgesGeometry`` on this mesh,
    where coplanar triangulation diagonals are dropped)."""
    edges = set()
    for f in faces:
        for a, b in zip(f, f[1:] + f[:1]):
            edges.add((min(a, b), max(a, b)))
    return np.array(sorted(edges))


def normalise_model(verts: np.ndarray, target: float = 1.6):
    """Centre the model and scale its longest side to ``target`` (as ``buildVectorObject``).

    Returns (verts, ground_y) where ground_y is the lowest point on the scene's vertical
    (three.js Y) axis after normalisation.
    """
    lo, hi = verts.min(axis=0), verts.max(axis=0)
    scale = target / max(float((hi - lo).max()), 1e-9)
    out = (verts - (lo + hi) / 2) * scale
    return out, float(out[:, 1].min())


# --------------------------------------------------------------------------- simulation
@dataclass
class ArmSim:
    """Time-stepped port of the JS animation loop."""

    seed: int = 7
    rot_speed: float = 0.35      # idleTargetVel (rad/s)
    pick_freq: float = 0.55      # 0..1
    ground_y: float = 0.0

    rng: random.Random = field(init=False)
    quat: np.ndarray = field(default_factory=lambda: IDENTITY.copy())
    pitch_wobble: float = 0.0
    idle_vel: float = 0.0
    state: str = "idle"
    t: float = 0.0               # global clock
    state_t: float = 0.0
    state_dur: float = 0.0
    from_q: np.ndarray = field(default_factory=lambda: IDENTITY.copy())
    to_q: np.ndarray = field(default_factory=lambda: IDENTITY.copy())
    next_event: float = 0.0
    picked: int = 0
    current: int | None = None
    screws: list = field(default_factory=list)       # dicts: x, z, taken, respawn_at

    def __post_init__(self):
        self.rng = random.Random(self.seed)
        self.next_event = self._rand(2, 4)
        self._scatter()

    # -- helpers --------------------------------------------------------------------
    def _rand(self, a, b):
        return a + self.rng.random() * (b - a)

    def _screw_pos(self, angle=None):
        angle = self._rand(0, 2 * math.pi) if angle is None else angle
        r = SCREW_RADIUS * (0.72 + self.rng.random() * 0.4)
        return math.cos(angle) * r, math.sin(angle) * r

    def _scatter(self):
        self.screws = []
        for i in range(SCREW_COUNT):
            angle = i / SCREW_COUNT * 2 * math.pi + (self.rng.random() - 0.5) * 0.4
            x, z = self._screw_pos(angle)
            self.screws.append({"x": x, "z": z, "taken": False, "respawn_at": None})

    def _pick_random(self) -> int:
        avail = [i for i, s in enumerate(self.screws) if not s["taken"]]
        if not avail:
            self._scatter()
            avail = list(range(len(self.screws)))
        return self.rng.choice(avail)

    def _start(self, state, to_q, dur):
        self.from_q = self.quat.copy()
        self.to_q = to_q
        self.state_t, self.state_dur, self.state = 0.0, dur, state

    # -- state transitions ----------------------------------------------------------
    def _start_aiming(self):
        self.current = self._pick_random()
        s = self.screws[self.current]
        yaw = math.atan2(s["x"], s["z"])
        self._start("aiming", q_from_euler_yxz(0.30, yaw), self._rand(0.7, 1.1))

    def _start_dipping(self):
        self._start("dipping", q_from_euler_yxz(0.62, q_yaw_yxz(self.quat)), 0.45)

    def _grab(self):
        if self.current is not None:
            self.screws[self.current]["taken"] = True
            self.picked += 1
        self._start("grabbed", self.quat.copy(), 0.22)

    def _start_lifting(self):
        self._start("lifting", q_from_euler_yxz(0.30, q_yaw_yxz(self.quat)), 0.4)

    def _start_returning(self):
        self._start("returning", IDENTITY.copy(), 0.85)

    def _finish(self):
        self.state = "idle"
        gap = self._rand(1.5, 5) * (1.4 - self.pick_freq)
        self.next_event = self.t + max(0.8, gap)
        if self.current is not None:
            self.screws[self.current]["respawn_at"] = self.t + self._rand(1.2, 3.0)

    _NEXT = {
        "aiming": "_start_dipping",
        "dipping": "_grab",
        "grabbed": "_start_lifting",
        "lifting": "_start_returning",
        "returning": "_finish",
    }

    # -- main step ------------------------------------------------------------------
    def step(self, dt: float) -> None:
        self.t += dt
        for s in self.screws:                      # replaces JS setTimeout respawn
            if s["respawn_at"] is not None and self.t >= s["respawn_at"]:
                s["x"], s["z"] = self._screw_pos()
                s["taken"], s["respawn_at"] = False, None

        if self.state == "idle":
            self.idle_vel += (self.rot_speed - self.idle_vel) * min(1.0, dt * 1.6)
            dq = q_from_axis_angle([0, 1, 0], self.idle_vel * dt)
            self.quat = q_normalize(q_mul(dq, self.quat))
            self.pitch_wobble = math.sin(self.t * 0.6) * 0.015     # nutation layer
            if self.t >= self.next_event:
                self._start_aiming()
        else:
            self.state_t += dt
            alpha = min(1.0, self.state_t / self.state_dur)
            self.quat = q_normalize(q_slerp(self.from_q, self.to_q, ease_in_out_cubic(alpha)))
            if alpha >= 1.0:
                getattr(self, self._NEXT[self.state])()

    @property
    def status(self) -> str:
        return STATUS_ES[self.state]

    def visible_screws(self):
        return [(s["x"], s["z"]) for s in self.screws if not s["taken"]]


def pose_vertices(verts: np.ndarray, quat: np.ndarray, wobble: float = 0.0) -> np.ndarray:
    """Apply the pivot quaternion (and the small x-nutation of the model group)."""
    if wobble:
        c, s = math.cos(wobble), math.sin(wobble)
        rx = np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
        verts = verts @ rx.T
    return verts @ q_to_matrix(quat).T


def record_animation(duration: float = 12.0, fps: int = 15, **sim_kwargs):
    """Run the simulation and return a list of frame dicts for the UI.

    Each frame: {"t", "state", "picked", "verts" (N×3, three.js axes), "screws" [(x, z)]}.
    """
    verts, faces = load_obj()
    verts, ground_y = normalise_model(verts)
    sim = ArmSim(ground_y=ground_y, **sim_kwargs)
    dt = 1.0 / fps
    frames = []
    for _ in range(int(duration * fps)):
        sim.step(dt)
        frames.append(
            {
                "t": sim.t,
                "state": sim.state,
                "picked": sim.picked,
                "verts": pose_vertices(verts, sim.quat, sim.pitch_wobble),
                "screws": sim.visible_screws(),
            }
        )
    return frames, outline_edges(faces), faces, ground_y
