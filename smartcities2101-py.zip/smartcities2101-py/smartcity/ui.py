"""Shared Streamlit page chrome (page config, header, CSS)."""

from __future__ import annotations

import streamlit as st

_CSS = """
<style>
  .block-container {padding-top: 2.2rem; max-width: 1200px;}
  .sc-eyebrow {font-size: .68rem; letter-spacing: .3em; text-transform: uppercase; color: #33f7c4; opacity: .85;}
  .sc-title {font-size: 1.6rem; font-weight: 600; margin: .1rem 0 .2rem;}
  .sc-sub {font-size: .8rem; color: #5f7b90; margin-bottom: 1rem;}
  .sc-card {border: 1px solid #17273a; border-radius: 6px; padding: .9rem 1rem; background: rgba(7,13,20,.72); height: 100%;}
  .sc-card h4 {margin: 0 0 .3rem; font-size: 1rem;}
  .sc-chip {display: inline-block; font-size: .68rem; padding: .05rem .5rem; margin: .1rem .15rem .1rem 0;
            border: 1px solid #0f5e4c; border-radius: 99px; color: #33f7c4;}
  .sc-mono {font-size: .72rem; color: #5f7b90;}
  [data-testid="stMetricValue"] {font-size: 1.5rem;}
</style>
"""


def setup(title: str, eyebrow: str, subtitle: str = "", icon: str = "🏙️", wide: bool = True) -> None:
    st.set_page_config(page_title=f"{title} · Smart City Platform", page_icon=icon,
                       layout="wide" if wide else "centered")
    st.markdown(_CSS, unsafe_allow_html=True)
    st.markdown(f"<div class='sc-eyebrow'>{eyebrow}</div><div class='sc-title'>{title}</div>"
                f"<div class='sc-sub'>{subtitle}</div>", unsafe_allow_html=True)


def card(title: str, body: str, footer: str = "", chips: list[str] | None = None) -> str:
    chips_html = "".join(f"<span class='sc-chip'>{c}</span>" for c in (chips or []))
    foot = f"<div class='sc-mono'>{footer}</div>" if footer else ""
    return f"<div class='sc-card'><h4>{title}</h4><div>{body}</div><div>{chips_html}</div>{foot}</div>"
