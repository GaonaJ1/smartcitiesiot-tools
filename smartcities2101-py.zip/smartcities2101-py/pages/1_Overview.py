import streamlit as st

from smartcity import content, ui

ui.setup("IoT sensors are the nervous system of the modern city.", "Field Report · 2026", icon="📡")
st.write(content.OVERVIEW_INTRO)

cols = st.columns(3)
for col, (big, text, src) in zip(cols, content.OVERVIEW_STATS):
    with col:
        st.metric(big, "")
        st.write(text)
        st.caption(src)

st.subheader("Explore the platform")
c1, c2 = st.columns(2)
with c1:
    st.markdown(ui.card("IoT Sensors for Smart Cities",
                        "A focused 650-word brief covering sensor families, communication architecture, "
                        "real-world applications, digital twins, deployment challenges, and what comes next.",
                        "FULL ARTICLE · 3 MIN READ"), unsafe_allow_html=True)
    st.page_link("pages/2_Article.py", label="Read the article →")
with c2:
    st.markdown(ui.card("Sensor Category Browser",
                        "Six sensor families that power smart-city deployments — what each measures, "
                        "the underlying tech, and where they show up in the urban stack.", "REFERENCE"),
                unsafe_allow_html=True)
    st.page_link("pages/3_Sensors.py", label="Browse the sensors →")

st.subheader("Telemetry preview")
cols = st.columns(3)
for i, (tag, title, desc, topic) in enumerate(content.TELEMETRY_PREVIEW):
    with cols[i % 3]:
        st.markdown(ui.card(title, desc, f"{tag} · <code>{topic}</code> · ● live"), unsafe_allow_html=True)
        st.write("")
