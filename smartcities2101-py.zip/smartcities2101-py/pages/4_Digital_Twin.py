import numpy as np
import streamlit as st

from smartcity import figures as F
from smartcity import h2_twin, ui

ui.setup("Green H₂ Power Simulator", "Integrated Digital Twin",
         "Hybrid solar + wind → PEM electrolyzer → H₂ storage · IoT node · DSP lab · FFT anomaly detector", icon="⚡")

with st.sidebar:
    hours = st.slider("Simulated hours", 24, 336, 96, step=24)
    seed = st.number_input("Random seed", 0, 9999, 42)

df = h2_twin.run_plant(hours, seed)
hour = st.slider("Time cursor (hour)", 0, hours - 1, min(30, hours - 1))
row = df.iloc[hour]

m = st.columns(5)
m[0].metric("Generation", f"{row.power_kw:,.0f} kW")
m[1].metric("H₂ rate", f"{row.h2_rate_kg_h:.2f} kg/h")
m[2].metric("H₂ stored", f"{row.storage_kg:,.0f} / 2000 kg")
m[3].metric("Efficiency", f"{row.efficiency * 100:.1f} %")
m[4].metric("IoT class", row.iot_class.replace("_", " "))

rng = np.random.default_rng(seed + hour)
fft = h2_twin.generate_fft(hour, rng)

t3d, tprod, tiot, tdsp, tfft = st.tabs(["3D plant", "Production", "IoT node", "DSP lab", "FFT analyzer"])
with t3d:
    st.plotly_chart(F.plant_figure(min(1.0, row.power_kw / 500), bool(row.led_on), fft["alert"]), use_container_width=True)
    st.caption("Electrolyzer opacity follows load; IoT block turns red when the LED rule fires "
               "(T > 30 °C or light < 3); FFT block turns red on a >15 Hz anomaly.")
with tprod:
    st.plotly_chart(F.line_chart(df, ["power_kw"], "Generation (kW)"), use_container_width=True)
    st.plotly_chart(F.line_chart(df, ["h2_rate_kg_h"], "H₂ production rate (kg/h)", [F.AMBER]), use_container_width=True)
    st.plotly_chart(F.line_chart(df, ["storage_kg", "h2_total_kg"], "H₂ storage vs cumulative (kg)"), use_container_width=True)
with tiot:
    st.plotly_chart(F.line_chart(df, ["temperature_c"], "Temperature (°C)", [F.AMBER]), use_container_width=True)
    st.plotly_chart(F.line_chart(df, ["light"], "Light (lux units)"), use_container_width=True)
    st.write(f"LED at hour {hour}: **{'ON' if row.led_on else 'off'}**")
with tdsp:
    d = h2_twin.generate_dsp(np.random.default_rng(seed))
    c = st.columns(4)
    c[0].metric("RMS noisy", f"{d['rms_noisy']:.3f}")
    c[1].metric("RMS envelope", f"{d['rms_rec']:.3f}")
    c[2].metric("RMS radar", f"{d['rms_radar']:.3f}")
    c[3].metric("RMS gated", f"{d['rms_final']:.3f}")
    st.plotly_chart(F.dsp_figure(d), use_container_width=True)
with tfft:
    st.plotly_chart(F.fft_figure(fft), use_container_width=True)
    if fft["alert"]:
        st.error("Anomaly: " + ", ".join(f"{f:.1f} Hz ({m:.2f})" for f, m, _ in fft["anomalies"]))
    else:
        st.success("Spectrum nominal (5 Hz + 12 Hz machine signature).")
