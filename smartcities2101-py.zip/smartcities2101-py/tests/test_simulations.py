import math

import numpy as np
import pytest

from smartcity import geometry as g
from smartcity import h2_twin, robot_arm, rpi_monitor, sensor_mesh


# ---- geometry ----------------------------------------------------------------
def test_quaternion_yaw_roundtrip():
    q = g.q_from_euler_yxz(0.3, 1.1)
    assert g.q_yaw_yxz(q) == pytest.approx(1.1, abs=1e-9)


def test_slerp_endpoints_and_unit_norm():
    a, b = g.IDENTITY, g.q_from_euler_yxz(0.6, 2.0)
    assert np.allclose(g.q_slerp(a, b, 0), a)
    assert np.allclose(g.q_slerp(a, b, 1), b)
    assert np.linalg.norm(g.q_slerp(a, b, 0.37)) == pytest.approx(1.0)


def test_easing_bounds():
    assert g.ease_in_out_cubic(0) == 0 and g.ease_in_out_cubic(1) == pytest.approx(1)


# ---- robot arm ---------------------------------------------------------------
def test_model_loads():
    verts, faces = robot_arm.load_obj()
    assert verts.shape == (230, 3) and len(faces) == 300
    assert len(robot_arm.outline_edges(faces)) == 510


def test_arm_completes_pick_cycles_deterministically():
    f1, *_ = robot_arm.record_animation(20, 15, seed=3)
    f2, *_ = robot_arm.record_animation(20, 15, seed=3)
    assert f1[-1]["picked"] >= 1
    assert np.allclose(f1[-1]["verts"], f2[-1]["verts"])
    assert {"aiming", "dipping", "grabbed", "lifting", "returning"} <= {f["state"] for f in f1}


# ---- green hydrogen twin -----------------------------------------------------
def test_plant_conservation_and_limits():
    df = h2_twin.run_plant(200, seed=1)
    assert (df.storage_kg <= 2000 + 1e-9).all()
    assert df.h2_total_kg.is_monotonic_increasing
    assert df.efficiency.min() >= 0.55 and df.power_kw.min() >= 0


def test_fft_port_matches_numpy():
    x = np.random.default_rng(0).standard_normal(256)
    assert np.allclose(h2_twin.fft_radix2(x), np.fft.fft(x))


def test_fft_detects_injected_anomaly():
    rng = np.random.default_rng(5)
    ok = h2_twin.generate_fft(0, rng, anomaly=False)
    bad = h2_twin.generate_fft(25, rng)
    assert not ok["alert"] and bad["alert"]
    assert any(abs(f - 35) < 1 for f, _, _ in bad["anomalies"])


def test_dsp_envelope_recovers_modulation():
    d = h2_twin.generate_dsp(np.random.default_rng(1))
    assert d["rms_rec"] < d["rms_noisy"]


# ---- raspberry pi ------------------------------------------------------------
def test_pi_bounds_over_long_run():
    m = rpi_monitor.PiMonitor(seed=9)
    for _ in range(2000):
        m.tick()
        assert 2 <= m.cpu <= 100 and m.temp <= 85 and 15 <= m.mem_pct <= 95 and m.disk_pct <= 90


def test_board_geometry():
    parts, wires = rpi_monitor.build_board([1] * 8)
    assert len(wires) == 17 and any("ON" in p["name"] for p in parts)


# ---- sensor mesh -------------------------------------------------------------
def test_odessa_sensors_are_stable():
    assert len(sensor_mesh.ODESSA_SENSORS) == 50
    assert sensor_mesh.ODESSA_SENSORS[0]["id"] == "OD-01"
    assert sensor_mesh.generate_odessa_sensors() == sensor_mesh.ODESSA_SENSORS


def test_mesh_congestion_is_derived():
    m = sensor_mesh.SensorMesh(seed=1).run(30)
    r = m.readings
    assert r[3].value == pytest.approx(r[1].value / (r[2].value + 1), abs=0.01)
    assert len(m.events) <= sensor_mesh.EVENT_LIMIT
    assert m.odessa_stats()["total"] == 50
