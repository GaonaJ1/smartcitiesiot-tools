import pandas as pd
import streamlit as st

from smartcity import figures as F
from smartcity import sensor_mesh as sm
from smartcity import ui

ui.setup("SMART CITY · OPS — Saltillo Mesh", "Sensor mesh · MQTT · digital twin",
         "Six city sensors publishing to city/sensorN/data, plus 50 threshold-based field sensors", icon="🛰️")

if "mesh" not in st.session_state:
    st.session_state.mesh = sm.SensorMesh().run(24)
mesh: sm.SensorMesh = st.session_state.mesh

with st.sidebar:
    live = st.toggle("Live feed (1 s)", value=True)
    city = st.radio("View", ["saltillo", "odessa"], format_func=str.title, horizontal=True)
    if st.button("Reset simulation"):
        st.session_state.mesh = sm.SensorMesh().run(24)
        st.rerun()


def console():
    if live:
        mesh.step()
    cards = st.columns(len(sm.SENSORS))
    for col, s in zip(cards, sm.SENSORS):
        r = mesh.readings[s.id]
        with col:
            st.metric(s.name, f"{r.value:g} {s.unit}", f"{r.delta:+.1f}")
            st.plotly_chart(F.sparkline(r.history, s.color), use_container_width=True, key=f"sp{s.id}")

    left, right = st.columns([3, 1])
    with left:
        st.plotly_chart(F.city_map(mesh, city), use_container_width=True, key="map")
    with right:
        gw = mesh.gateway_health()
        st.markdown("**Gateway · :8000**")
        st.write(f"Service: `{gw['service']}` · Sensors up: `{gw['sensors_up']}`")
        st.metric("Msg/s", gw["rate"])
        for label, v in (("CPU", gw["cpu"]), ("MEM", gw["mem"]), ("NET", gw["net"])):
            st.progress(min(1.0, v / 100), text=f"{label} {v:.0f}%")
        o = mesh.odessa_stats()
        st.markdown(f"**Odessa field sensors:** {o['active']} / {o['total']} active")
        for k, v in o["by_type"].items():
            st.caption(f"{k}: {v['active']}/{v['total']}")

    st.markdown("**Event feed**")
    feed = pd.DataFrame([{"time": e["ts"].strftime("%H:%M:%S"), "topic": e["topic"],
                          "sensor": e["payload"]["sensor"], "value": e["payload"]["value"]} for e in mesh.events[:15]])
    st.dataframe(feed, hide_index=True, use_container_width=True)


st.fragment(run_every="1s" if live else None)(console)()
