import streamlit as st

from smartcity import content, ui

ui.setup("Sensor Categories", "Reference · 6 Families",
         "The sensor families that compose every modern smart-city deployment — what they measure, "
         "the underlying tech, and the urban services they power.", icon="🧭")

cols = st.columns(2)
for i, f in enumerate(content.SENSOR_FAMILIES):
    with cols[i % 2]:
        label, value = f["meta"]
        st.markdown(ui.card(f"{f['n']} · {f['name']}",
                            f"<div class='sc-mono'>{f['topic']}</div><p>{f['desc']}</p>",
                            f"<b>{label}:</b> {value}", chips=f["tags"]), unsafe_allow_html=True)
        st.write("")

st.subheader("Communication Stack — edge to cloud")
for layer, desc, tech in content.COMM_STACK:
    c1, c2, c3 = st.columns([1, 3, 2])
    c1.markdown(f"**{layer}**")
    c2.write(desc)
    c3.caption(tech)
