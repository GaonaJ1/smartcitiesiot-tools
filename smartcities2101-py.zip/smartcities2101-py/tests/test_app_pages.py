"""Smoke-test every Streamlit page headlessly, navigating from app.py like a real session."""

from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent.parent
PAGES = sorted(str(p.relative_to(ROOT)) for p in (ROOT / "pages").glob("*.py"))


def test_home_runs():
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    assert not at.exception, [e.value for e in at.exception]


@pytest.mark.parametrize("page", PAGES)
def test_page_runs(page):
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    at.switch_page(page).run()
    assert not at.exception, [e.value for e in at.exception]
