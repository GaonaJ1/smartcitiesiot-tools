"""Plotly figure builders for every page (3D scenes, charts, maps)."""

from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from . import h2_twin, robot_arm, rpi_monitor, sensor_mesh
from .geometry import cylinder_mesh, ellipsoid_mesh, box_mesh

BG = "rgba(0,0,0,0)"
GRID = "#17273a"
TEXT = "#cfe3ee"
ACCENT = "#33f7c4"
AMBER = "#f2a341"
FONT = dict(family="JetBrains Mono, monospace", color=TEXT, size=11)


def _base_layout(fig: go.Figure, height: int = 520, **kw) -> go.Figure:
    fig.update_layout(paper_bgcolor=BG, plot_bgcolor=BG, font=FONT, height=height,
                      margin=dict(l=10, r=10, t=40, b=10), **kw)
    return fig


def _scene(rng=None, aspect="data", **kw):
    ax = dict(backgroundcolor=BG, gridcolor=GRID, zerolinecolor=GRID, color=TEXT, showspikes=False)
    return dict(xaxis=dict(ax, **(kw.get("x", {}))), yaxis=dict(ax, **(kw.get("y", {}))),
                zaxis=dict(ax, **(kw.get("z", {}))), aspectmode=aspect, bgcolor=BG,
                camera=kw.get("camera"))


def _polyline(segments):
    """[(p0, p1), ...] → x, y, z arrays with None separators."""
    xs, ys, zs = [], [], []
    for a, b in segments:
        xs += [a[0], b[0], None]
        ys += [a[1], b[1], None]
        zs += [a[2], b[2], None]
    return xs, ys, zs


# =========================================================================== robotic arm
def arm_figure(frames, edges, faces, ground_y, wireframe: bool = True, fps: int = 15) -> go.Figure:
    """Animated model. three.js axes (x, y-up, z) are remapped to Plotly (x, z, y)."""

    def model_trace(verts):
        v = np.round(verts, 3)
        if wireframe:
            segs = [(v[a], v[b]) for a, b in edges]
            x, y, z = _polyline([((a[0], a[2], a[1]), (b[0], b[2], b[1])) for a, b in segs])
            return go.Scatter3d(x=x, y=y, z=z, mode="lines", line=dict(color=ACCENT, width=3),
                                hoverinfo="skip", name="arm")
        tris = np.array([[f[0], f[i], f[i + 1]] for f in faces for i in range(1, len(f) - 1)])
        return go.Mesh3d(x=v[:, 0], y=v[:, 2], z=v[:, 1], i=tris[:, 0], j=tris[:, 1], k=tris[:, 2],
                         color="#0b2a24", flatshading=True, opacity=1, name="arm",
                         lighting=dict(ambient=0.5, diffuse=0.8), hoverinfo="skip")

    def screw_trace(screws):
        xs = [s[0] for s in screws]
        zs = [s[1] for s in screws]
        return go.Scatter3d(x=xs, y=zs, z=[ground_y] * len(xs), mode="markers",
                            marker=dict(size=6, color=AMBER, symbol="diamond"), name="screws",
                            hoverinfo="skip")

    ang = np.linspace(0, 2 * np.pi, 80)
    ring = go.Scatter3d(x=1.45 * np.cos(ang), y=1.45 * np.sin(ang), z=[ground_y] * len(ang), mode="lines",
                        line=dict(color="#0f5e4c", width=2), hoverinfo="skip", name="work area")

    f0 = frames[0]
    fig = go.Figure(data=[model_trace(f0["verts"]), screw_trace(f0["screws"]), ring])
    fig.frames = [
        go.Frame(data=[model_trace(f["verts"]), screw_trace(f["screws"])], traces=[0, 1], name=str(i),
                 layout=go.Layout(title_text=f"{robot_arm.STATUS_ES[f['state']]} · tornillos: {f['picked']}"))
        for i, f in enumerate(frames)
    ]
    dur = int(1000 / fps)
    fig.update_layout(
        title=dict(text=f"{robot_arm.STATUS_ES[f0['state']]} · tornillos: {f0['picked']}", font=dict(color=ACCENT, size=13)),
        showlegend=False,
        scene=_scene(aspect="cube", x=dict(range=[-1.6, 1.6]), y=dict(range=[-1.6, 1.6]), z=dict(range=[-1.2, 1.2]),
                     camera=dict(eye=dict(x=1.5, y=-1.9, z=0.9))),
        updatemenus=[dict(type="buttons", direction="left", x=0.0, y=0.0, xanchor="left", yanchor="top",
                          buttons=[
                              dict(label="▶ Play", method="animate",
                                   args=[None, dict(frame=dict(duration=dur, redraw=True), transition=dict(duration=0), fromcurrent=True)]),
                              dict(label="❚❚ Pause", method="animate",
                                   args=[[None], dict(frame=dict(duration=0, redraw=False), mode="immediate", transition=dict(duration=0))]),
                          ])],
        sliders=[dict(active=0, x=0.18, len=0.8, currentvalue=dict(visible=False), pad=dict(t=0, b=0),
                      steps=[dict(method="animate", label="", args=[[str(i)], dict(mode="immediate", frame=dict(duration=0, redraw=True), transition=dict(duration=0))])
                             for i in range(len(frames))])],
    )
    return _base_layout(fig, height=560)


# =========================================================================== breadboard
def board_figure(gpio_states, show_wires: bool = True) -> go.Figure:
    parts, wires = rpi_monitor.build_board(gpio_states)
    fig = go.Figure()
    for p in parts:
        v, t = p["verts"], p["tris"]
        fig.add_trace(go.Mesh3d(x=v[:, 0], y=v[:, 1], z=v[:, 2], i=t[:, 0], j=t[:, 1], k=t[:, 2],
                                color=p["color"], opacity=p["opacity"], flatshading=True, name=p["name"],
                                hovertemplate=p["name"] + "<extra></extra>",
                                lighting=dict(ambient=0.55, diffuse=0.8)))
    if show_wires:
        for pts, colour, name in wires:
            a = np.array(pts)
            fig.add_trace(go.Scatter3d(x=a[:, 0], y=a[:, 1], z=a[:, 2], mode="lines",
                                       line=dict(color=colour, width=5), name=name,
                                       hovertemplate=name + "<extra></extra>"))
    fig.update_layout(showlegend=False,
                      scene=_scene(aspect="data", camera=dict(eye=dict(x=0.9, y=-1.6, z=1.1))))
    fig.update_scenes(xaxis_visible=False, yaxis_visible=False, zaxis_visible=False)
    return _base_layout(fig, height=520)


def gauge(value: float, title: str, suffix: str, max_v: float = 100, color: str = ACCENT) -> go.Figure:
    fig = go.Figure(go.Indicator(mode="gauge+number", value=value, number=dict(suffix=suffix, font=dict(size=26)),
                                 title=dict(text=title, font=dict(size=12)),
                                 gauge=dict(axis=dict(range=[0, max_v], tickcolor=TEXT), bar=dict(color=color),
                                            bgcolor="#0b1420", borderwidth=0)))
    return _base_layout(fig, height=170).update_layout(margin=dict(l=20, r=20, t=40, b=0))


# =========================================================================== H₂ digital twin
def _mesh_trace(mesh, color, name, opacity=1.0):
    v, t = mesh
    return go.Mesh3d(x=v[:, 0], y=v[:, 1], z=v[:, 2], i=t[:, 0], j=t[:, 1], k=t[:, 2], color=color,
                     opacity=opacity, flatshading=True, name=name, hovertemplate=name + "<extra></extra>")


def plant_figure(load: float = 0.5, led_alert: bool = False, fft_alert: bool = False) -> go.Figure:
    """3D layout of the plant. ``load`` (0-1) shades the electrolyzer like the Cesium page."""
    fig = go.Figure()
    for name, (dlon, dlat, h), kind, colour in h2_twin.COMPONENTS:
        e, n = h2_twin.to_local_m(dlon, dlat)
        if name == "PEM ELECTROLYZER":
            colour = f"rgba(0,229,255,{0.3 + load * 0.5:.2f})"
            mesh = box_mesh(e, n, h / 2, 90, 90, h)
        elif name == "FFT ANALYSIS" and fft_alert:
            colour, mesh = "#ff3b3b", box_mesh(e, n, h / 2, 70, 70, h)
        elif kind == "tank":
            mesh = ellipsoid_mesh(e, n, h, 55, 55, 40)
        elif kind == "cyl":
            mesh = cylinder_mesh(e, n, h / 2, h, 20, 20, 16)
        else:
            mesh = box_mesh(e, n, h / 2, 60, 60, max(h, 6))
        if name == "IoT SENSORS" and led_alert:
            colour = "#ff3b3b"
        fig.add_trace(_mesh_trace(mesh, colour, name, 0.85))
        fig.add_trace(go.Scatter3d(x=[e], y=[n], z=[h + 22], mode="text", text=[name], textfont=dict(size=9, color=TEXT),
                                   hoverinfo="skip", showlegend=False))
    for dlon, dlat in h2_twin.TURBINES:
        e, n = h2_twin.to_local_m(dlon, dlat)
        fig.add_trace(_mesh_trace(cylinder_mesh(e, n, 40, 80, 1.5, 4, 12), "#ffffff", "Wind turbine"))
        blades = [((e, n, 80), (e + 66 * np.cos(a), n + 66 * np.sin(a), 80)) for a in (0, 2.094, 4.189)]
        x, y, z = _polyline(blades)
        fig.add_trace(go.Scatter3d(x=x, y=y, z=z, mode="lines", line=dict(color="#ffffff", width=6),
                                   hoverinfo="skip", showlegend=False))
    for (a, b, colour) in h2_twin.FLOWS:
        pa, pb = (*h2_twin.to_local_m(a[0], a[1]), a[2]), (*h2_twin.to_local_m(b[0], b[1]), b[2])
        x, y, z = _polyline([(pa, pb)])
        fig.add_trace(go.Scatter3d(x=x, y=y, z=z, mode="lines+markers", line=dict(color=colour, width=4),
                                   marker=dict(size=3, color=colour), hoverinfo="skip", showlegend=False))
    fig.update_layout(showlegend=False, scene=_scene(aspect="data", camera=dict(eye=dict(x=1.2, y=-1.6, z=0.9)),
                                                      x=dict(title="east (m)"), y=dict(title="north (m)"), z=dict(title="up (m)")))
    return _base_layout(fig, height=560)


def line_chart(df, cols, title, colors=None, height=260, yaxis_title=None) -> go.Figure:
    fig = go.Figure()
    for i, c in enumerate(cols):
        fig.add_trace(go.Scatter(x=df["hour"], y=df[c], mode="lines", name=c,
                                 line=dict(color=(colors or [ACCENT, AMBER, "#b388ff"])[i % 3], width=2)))
    fig.update_layout(title=title, xaxis_title="hour", yaxis_title=yaxis_title)
    fig.update_xaxes(gridcolor=GRID)
    fig.update_yaxes(gridcolor=GRID)
    return _base_layout(fig, height=height)


def dsp_figure(d: dict) -> go.Figure:
    fig = make_subplots(rows=2, cols=2, subplot_titles=("AM signal (noisy)", "Envelope (rectify + MA)",
                                                        "Radar raw vs DC-removed", "Gated output"))
    t = d["t"] * 1000
    fig.add_trace(go.Scatter(x=t, y=d["am"], line=dict(color="#6b7f93", width=1), name="noisy"), 1, 1)
    fig.add_trace(go.Scatter(x=t, y=d["rec"], line=dict(color=ACCENT, width=2), name="envelope"), 1, 2)
    fig.add_trace(go.Scatter(x=t, y=d["radar_raw"], line=dict(color="#6b7f93", width=1), name="raw"), 2, 1)
    fig.add_trace(go.Scatter(x=t, y=d["radar_proc"], line=dict(color="#b388ff", width=2), name="clean"), 2, 1)
    fig.add_trace(go.Scatter(x=t, y=d["gated"], line=dict(color=AMBER, width=2), name="gated"), 2, 2)
    fig.update_xaxes(title_text="ms", gridcolor=GRID)
    fig.update_yaxes(gridcolor=GRID)
    fig.update_layout(showlegend=False)
    return _base_layout(fig, height=420)


def fft_figure(f: dict) -> go.Figure:
    colors = [("#ff3b3b" if fr > 15 and m > 0.08 else ACCENT) for fr, m in zip(f["freqs"], f["mags"])]
    fig = go.Figure(go.Bar(x=f["freqs"], y=f["mags"], marker_color=colors))
    fig.update_layout(title=f"FFT spectrum — dominant {f['dom_freq']:.1f} Hz" + ("  ⚠ anomaly" if f["alert"] else ""),
                      xaxis_title="Hz", yaxis_title="|X|")
    fig.update_xaxes(gridcolor=GRID)
    fig.update_yaxes(gridcolor=GRID)
    return _base_layout(fig, height=300)


# =========================================================================== ops dashboard
def sparkline(history, color, height=60) -> go.Figure:
    fig = go.Figure(go.Scatter(y=history, mode="lines", line=dict(color=color, width=2), fill="tozeroy",
                               fillcolor=color.replace("#", "#") + "22"))
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    return _base_layout(fig, height=height).update_layout(margin=dict(l=0, r=0, t=0, b=0))


def city_map(mesh: "sensor_mesh.SensorMesh", city: str = "saltillo") -> go.Figure:
    fig = go.Figure()
    if city == "saltillo":
        for s in sensor_mesh.SENSORS:
            r = mesh.readings[s.id]
            fig.add_trace(go.Scattermap(lat=[s.lat], lon=[s.lng], mode="markers+text", name=s.name,
                                        marker=dict(size=16, color=s.color), text=[f"{s.name}: {r.value:g} {s.unit}"],
                                        textposition="top right", hoverinfo="text"))
        c_lat, c_lng = sensor_mesh.SALTILLO_CENTER
        zoom = 11.3
    else:
        state = mesh.odessa_state()
        for s in sensor_mesh.SENSORS:
            pts = [p for p in state if p["type"] == s.key]
            fig.add_trace(go.Scattermap(
                lat=[p["lat"] for p in pts], lon=[p["lng"] for p in pts], mode="markers", name=s.name,
                marker=dict(size=[13 if p["on"] else 8 for p in pts], color=[s.color if p["on"] else "#4b5563" for p in pts]),
                text=[f"{p['id']} · {s.key} · {'ON' if p['on'] else 'off'} ({p['value']:.1f} vs {p['threshold']})" for p in pts],
                hoverinfo="text"))
        c_lat, c_lng = sensor_mesh.ODESSA_CENTER
        zoom = 10.2
    fig.update_layout(map=dict(style="open-street-map", center=dict(lat=c_lat, lon=c_lng), zoom=zoom),
                      legend=dict(orientation="h", y=-0.02))
    return _base_layout(fig, height=520).update_layout(margin=dict(l=0, r=0, t=0, b=0))
