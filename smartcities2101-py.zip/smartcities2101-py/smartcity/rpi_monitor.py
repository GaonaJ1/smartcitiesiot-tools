"""Raspberry Pi Linux monitor — telemetry simulation + breadboard 3D geometry.

Port of ``breadboard-3d.html`` (which itself mirrored ``linux_monitor.py``): CPU, thermal,
memory, disk, load average, network, 8 GPIO pins, I²C bus scan and systemd service health.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field

import numpy as np

from .geometry import box_mesh, cylinder_mesh

GPIO_PINS = [17, 27, 22, 5, 23, 24, 6, 13]
SERVICES = [("greenpower", 1842), ("mosquitto", 923), ("sshd", 412), ("cron", 389), ("journald", 201)]
I2C_DEVICES = [("0x48", "ADS1115 (ADC)"), ("0x40", "INA219 (Current)"), ("0x76", "BME280 (Temp)"), ("0x3c", "SSD1306 (OLED)")]


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


@dataclass
class PiMonitor:
    seed: int = 1
    cycle: int = 0
    cpu: float = 12.0
    temp: float = 45.0
    freq: int = 1500
    mem_pct: float = 35.0
    mem_total: int = 1024
    disk_pct: float = 42.0
    uptime_sec: int = 345_600
    load: list = field(default_factory=lambda: [0.45, 0.38, 0.32])
    rx_kbs: float = 12.4
    tx_kbs: float = 3.2
    signal_dbm: int = -42
    rng: random.Random = field(init=False)
    gpio: list = field(init=False)
    services: list = field(init=False)

    def __post_init__(self):
        self.rng = random.Random(self.seed)
        self.gpio = [self.rng.random() > 0.5 and 1 or 0 for _ in GPIO_PINS]
        self.services = [{"name": n, "active": True, "sub": "running", "pid": p} for n, p in SERVICES]

    def _r(self, a, b):
        return a + self.rng.random() * (b - a)

    @property
    def mem_used(self) -> int:
        return round(self.mem_total * self.mem_pct / 100)

    def tick(self) -> None:
        """One 5-second sampling cycle (same random-walk model as the page)."""
        self.cycle += 1
        target = min(100, max(2, self.cpu + self._r(-8, 8)))
        self.cpu = lerp(self.cpu, target, 0.3)
        self.temp = lerp(self.temp, min(85, 38 + self.cpu * 0.35 + self._r(-2, 2)), 0.2)
        self.freq = 1500 if self.cpu > 60 else (1200 if self.cpu > 30 else 600)
        self.mem_pct = min(95, max(15, self.mem_pct + self._r(-3, 3)))
        self.disk_pct = min(90, self.disk_pct + self._r(0, 0.05))
        self.uptime_sec += 5
        self.load[0] = max(0.01, self.load[0] + self._r(-0.15, 0.15))
        self.load[1] = lerp(self.load[1], self.load[0], 0.1)
        self.load[2] = lerp(self.load[2], self.load[1], 0.05)
        if self.cycle % 3 == 0:
            i = int(self._r(0, len(GPIO_PINS)))
            self.gpio[i] ^= 1
        self.rx_kbs = max(0, self.rx_kbs + self._r(-8, 8))
        self.tx_kbs = max(0, self.tx_kbs + self._r(-3, 3))
        self.signal_dbm = round(-30 + self._r(-20, 5))
        if self.rng.random() < 0.02:                  # occasional service flicker
            s = self.services[int(self._r(2, 5))]
            s["active"] = not s["active"]
            s["sub"] = "running" if s["active"] else "dead"

    def snapshot(self) -> dict:
        return dict(cycle=self.cycle, cpu=self.cpu, temp=self.temp, freq=self.freq,
                    mem_pct=self.mem_pct, mem_used=self.mem_used, disk_pct=self.disk_pct,
                    load1=self.load[0], load5=self.load[1], load15=self.load[2],
                    rx_kbs=self.rx_kbs, tx_kbs=self.tx_kbs, signal_dbm=self.signal_dbm,
                    services_up=sum(s["active"] for s in self.services))


def temp_band(temp_c: float) -> str:
    return "hot" if temp_c > 70 else "warm" if temp_c > 55 else "cool"


def fmt_uptime(sec: int) -> str:
    d, rem = divmod(int(sec), 86_400)
    h, rem = divmod(rem, 3600)
    return f"{d}d {h}h {rem // 60}m"


# --------------------------------------------------------------------------- 3D board
def build_board(gpio_states=None):
    """Return a list of Plotly-ready parts: dicts with ``verts``, ``tris``, ``color``,
    ``name``, plus wire polylines. Units: metres, Z up (same as the Cesium ENU frame)."""
    gpio_states = gpio_states or [0] * 8
    parts, wires = [], []

    def add(name, mesh, color, opacity=1.0):
        parts.append(dict(name=name, verts=mesh[0], tris=mesh[1], color=color, opacity=opacity))

    add("Breadboard", box_mesh(0, 0, 0, 0.170, 0.058, 0.010), "#e9e4d6")
    add("Center channel", box_mesh(0, 0, 0.006, 0.160, 0.003, 0.002), "#c5c0b5")
    add("+ rail", box_mesh(0, 0.026, 0.006, 0.160, 0.004, 0.001), "#ef4444", 0.5)
    add("− rail", box_mesh(0, -0.026, 0.006, 0.160, 0.004, 0.001), "#3b82f6", 0.5)

    px, py, pz = -0.035, 0.0, 0.012            # Raspberry Pi origin
    add("Pi PCB", box_mesh(px, py, pz, 0.085, 0.046, 0.002), "#0f7b3d")
    add("SoC", box_mesh(px + 0.005, py + 0.003, pz + 0.003, 0.014, 0.014, 0.003), "#2a2a2a")
    add("SoC spreader", box_mesh(px + 0.005, py + 0.003, pz + 0.005, 0.012, 0.012, 0.001), "#c0c0c0")
    add("RAM", box_mesh(px + 0.005, py - 0.012, pz + 0.002, 0.010, 0.008, 0.001), "#1a1a1a")
    add("GPIO header", box_mesh(px, py + 0.020, pz + 0.005, 0.051, 0.005, 0.008), "#1a1a1a")
    add("USB", box_mesh(px + 0.040, py + 0.008, pz + 0.008, 0.008, 0.014, 0.012), "#9ca3af")
    add("USB", box_mesh(px + 0.040, py - 0.008, pz + 0.008, 0.008, 0.014, 0.012), "#9ca3af")
    add("Ethernet", box_mesh(px + 0.040, py - 0.022, pz + 0.009, 0.008, 0.016, 0.014), "#6b7280")
    add("HDMI", box_mesh(px - 0.032, py - 0.018, pz + 0.004, 0.012, 0.005, 0.004), "#111827")
    add("USB-C power", box_mesh(px - 0.040, py, pz + 0.004, 0.005, 0.008, 0.003), "#9ca3af")
    add("SD slot", box_mesh(px + 0.010, py - 0.024, pz + 0.001, 0.012, 0.004, 0.002), "#374151")

    mod_z = 0.012                                # I²C modules
    add("ADS1115 ADC (0x48)", box_mesh(0.050, 0.015, mod_z, 0.020, 0.014, 0.002), "#7c3aed")
    add("INA219 current (0x40)", box_mesh(0.050, -0.002, mod_z, 0.020, 0.010, 0.002), "#dc2626")
    add("BME280 temp (0x76)", box_mesh(0.050, -0.017, mod_z, 0.016, 0.010, 0.002), "#2563eb")
    add("SSD1306 OLED (0x3c)", box_mesh(0.073, 0.0, mod_z, 0.018, 0.032, 0.002), "#111827")
    add("OLED screen", box_mesh(0.073, 0.003, mod_z + 0.002, 0.014, 0.022, 0.001), "#38bdf8")

    for i, pin in enumerate(GPIO_PINS):          # 8 GPIO LEDs
        lx, ly, lz = -0.060 + i * 0.010, -0.028, 0.010
        on = bool(gpio_states[i])
        colour = "#22c55e" if on else "#14532d"
        add(f"LED GPIO{pin} {'ON' if on else 'off'}", cylinder_mesh(lx, ly, lz + 0.002, 0.007, 0.0025, 0.0025, 10), colour)

    w_h = 0.020                                   # wire arc height
    wires += [
        ([[px - 0.010, py + 0.020, pz + 0.008], [px - 0.010, py + 0.020, pz + w_h], [-0.070, 0.026, w_h], [-0.070, 0.026, 0.007]], "#ef4444", "5V → + rail"),
        ([[px - 0.007, py + 0.020, pz + 0.008], [px - 0.007, py + 0.020, pz + w_h + 0.003], [-0.065, -0.026, w_h + 0.003], [-0.065, -0.026, 0.007]], "#111827", "GND → − rail"),
        ([[px + 0.002, py + 0.020, pz + 0.008], [px + 0.002, py + 0.020, pz + w_h + 0.005], [0.044, 0.009, w_h + 0.005], [0.044, 0.009, mod_z - 0.003]], "#22c55e", "I²C SDA"),
        ([[px + 0.005, py + 0.020, pz + 0.008], [px + 0.005, py + 0.020, pz + w_h + 0.008], [0.048, 0.009, w_h + 0.008], [0.048, 0.009, mod_z - 0.003]], "#eab308", "I²C SCL"),
        ([[0.048, 0.009, mod_z], [0.048, 0.009, mod_z + 0.010], [0.048, -0.006, mod_z + 0.010], [0.048, -0.006, mod_z - 0.003]], "#22c55e", "SDA daisy"),
        ([[0.044, 0.009, mod_z], [0.044, 0.009, mod_z + 0.012], [0.044, -0.006, mod_z + 0.012], [0.044, -0.006, mod_z - 0.003]], "#eab308", "SCL daisy"),
        ([[0.052, 0.009, mod_z], [0.052, 0.009, mod_z + 0.015], [0.066, -0.014, mod_z + 0.015], [0.066, -0.014, mod_z - 0.003]], "#06b6d4", "OLED link"),
        ([[0.060, 0.026, 0.007], [0.060, 0.026, 0.015], [0.056, 0.015, 0.015], [0.056, 0.015, mod_z]], "#ef4444", "VCC modules"),
        ([[0.060, -0.026, 0.007], [0.060, -0.026, 0.015], [0.056, -0.017, 0.015], [0.056, -0.017, mod_z]], "#111827", "GND modules"),
    ]
    palette = ["#f97316", "#eab308", "#22c55e", "#a855f7", "#3b82f6", "#06b6d4", "#ef4444", "#22c55e"]
    for i in range(8):                            # GPIO header → LED wires
        lx = -0.060 + i * 0.010
        gx = px - 0.020 + i * 0.00254 * 2
        wires.append(([[gx, py + 0.020, pz + 0.008], [gx, py + 0.020, pz + 0.015 + i * 0.001],
                       [lx, -0.028, 0.015 + i * 0.001], [lx, -0.028, 0.012]], palette[i], f"GPIO{GPIO_PINS[i]}"))
    return parts, wires
