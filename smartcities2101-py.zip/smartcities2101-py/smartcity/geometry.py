"""Small 3D helpers shared by the Plotly scenes: quaternions and mesh primitives.

Quaternions are stored as ``np.array([x, y, z, w])`` (same layout as three.js, which
the original ``robotic-arm-3d.html`` used).
"""

from __future__ import annotations

import numpy as np

# --------------------------------------------------------------------------- quaternions
IDENTITY = np.array([0.0, 0.0, 0.0, 1.0])


def q_mul(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Hamilton product a * b."""
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return np.array(
        [
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
            aw * bw - ax * bx - ay * by - az * bz,
        ]
    )


def q_from_axis_angle(axis, angle: float) -> np.ndarray:
    axis = np.asarray(axis, dtype=float)
    axis = axis / np.linalg.norm(axis)
    s = np.sin(angle / 2.0)
    return np.array([axis[0] * s, axis[1] * s, axis[2] * s, np.cos(angle / 2.0)])


def q_from_euler_yxz(x: float, y: float, z: float = 0.0) -> np.ndarray:
    """Quaternion for a three.js ``Euler(x, y, z, 'YXZ')`` (R = Ry · Rx · Rz)."""
    qx = q_from_axis_angle([1, 0, 0], x)
    qy = q_from_axis_angle([0, 1, 0], y)
    qz = q_from_axis_angle([0, 0, 1], z)
    return q_mul(q_mul(qy, qx), qz)


def q_to_matrix(q: np.ndarray) -> np.ndarray:
    x, y, z, w = q / np.linalg.norm(q)
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def q_yaw_yxz(q: np.ndarray) -> float:
    """Yaw (rotation about Y) of a quaternion decomposed as Euler 'YXZ'."""
    m = q_to_matrix(q)
    if abs(m[1, 2]) < 0.9999999:
        return float(np.arctan2(m[0, 2], m[2, 2]))
    return float(np.arctan2(-m[2, 0], m[0, 0]))


def q_slerp(a: np.ndarray, b: np.ndarray, t: float) -> np.ndarray:
    """Spherical linear interpolation along the shortest path."""
    cos_half = float(np.dot(a, b))
    if cos_half < 0:  # take the short way round
        b = -b
        cos_half = -cos_half
    if cos_half > 0.9995:  # nearly parallel → lerp
        out = a + t * (b - a)
        return out / np.linalg.norm(out)
    half = np.arccos(cos_half)
    sin_half = np.sin(half)
    ra = np.sin((1 - t) * half) / sin_half
    rb = np.sin(t * half) / sin_half
    return a * ra + b * rb


def q_normalize(q: np.ndarray) -> np.ndarray:
    return q / np.linalg.norm(q)


def ease_in_out_cubic(t: float) -> float:
    return 4 * t**3 if t < 0.5 else 1 - (-2 * t + 2) ** 3 / 2


# --------------------------------------------------------------------------- mesh primitives
_BOX_TRIS = np.array(
    [
        [0, 1, 2], [0, 2, 3],  # bottom
        [4, 6, 5], [4, 7, 6],  # top
        [0, 5, 1], [0, 4, 5],  # front
        [1, 6, 2], [1, 5, 6],  # right
        [2, 7, 3], [2, 6, 7],  # back
        [3, 4, 0], [3, 7, 4],  # left
    ]
)


def box_mesh(cx, cy, cz, w, d, h):
    """Axis-aligned box centred on (cx, cy, cz) with size (w, d, h). Returns (verts, tris)."""
    hx, hy, hz = w / 2, d / 2, h / 2
    v = np.array(
        [
            [cx - hx, cy - hy, cz - hz], [cx + hx, cy - hy, cz - hz],
            [cx + hx, cy + hy, cz - hz], [cx - hx, cy + hy, cz - hz],
            [cx - hx, cy - hy, cz + hz], [cx + hx, cy - hy, cz + hz],
            [cx + hx, cy + hy, cz + hz], [cx - hx, cy + hy, cz + hz],
        ]
    )
    return v, _BOX_TRIS.copy()


def cylinder_mesh(cx, cy, cz, length, r_top, r_bot, n: int = 14):
    """Vertical (Z-axis) cylinder / frustum centred on (cx, cy, cz)."""
    ang = np.linspace(0, 2 * np.pi, n, endpoint=False)
    z0, z1 = cz - length / 2, cz + length / 2
    bot = np.c_[cx + r_bot * np.cos(ang), cy + r_bot * np.sin(ang), np.full(n, z0)]
    top = np.c_[cx + r_top * np.cos(ang), cy + r_top * np.sin(ang), np.full(n, z1)]
    v = np.vstack([bot, top, [[cx, cy, z0]], [[cx, cy, z1]]])
    tris = []
    for i in range(n):
        j = (i + 1) % n
        tris += [[i, j, n + j], [i, n + j, n + i], [2 * n, j, i], [2 * n + 1, n + i, n + j]]
    return v, np.array(tris)


def ellipsoid_mesh(cx, cy, cz, rx, ry, rz, n_lat: int = 10, n_lon: int = 16):
    """UV-sphere style ellipsoid."""
    lat = np.linspace(-np.pi / 2, np.pi / 2, n_lat)
    lon = np.linspace(0, 2 * np.pi, n_lon, endpoint=False)
    verts = [
        [cx + rx * np.cos(la) * np.cos(lo), cy + ry * np.cos(la) * np.sin(lo), cz + rz * np.sin(la)]
        for la in lat for lo in lon
    ]
    tris = []
    for i in range(n_lat - 1):
        for j in range(n_lon):
            a = i * n_lon + j
            b = i * n_lon + (j + 1) % n_lon
            c = (i + 1) * n_lon + j
            d = (i + 1) * n_lon + (j + 1) % n_lon
            tris += [[a, b, d], [a, d, c]]
    return np.array(verts), np.array(tris)


def merge_meshes(parts):
    """Concatenate [(verts, tris), ...] into a single mesh."""
    vs, ts, off = [], [], 0
    for v, t in parts:
        vs.append(v)
        ts.append(t + off)
        off += len(v)
    return np.vstack(vs), np.vstack(ts)
