"""Saltillo ops console — MQTT-style sensor mesh simulation.

Port of the React/Cesium ``dashboard.html``: six city sensors random-walk around a
baseline (with mean reversion), a derived congestion index, an event feed, gateway health
metrics and 50 deterministic "Odessa" field sensors that switch on when the live value of
their sensor type exceeds a per-sensor threshold.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from datetime import datetime, timedelta

HISTORY_LEN = 24
EVENT_LIMIT = 80


@dataclass(frozen=True)
class Sensor:
    id: int
    key: str
    name: str
    topic: str
    unit: str
    lat: float
    lng: float
    baseline: float
    range: float
    color: str
    derived: bool = False


SENSORS = [
    Sensor(1, "traffic", "Traffic Flow", "city/sensor1/data", "veh/min", 25.4232, -100.9994, 50, 30, "#f4a02f"),
    Sensor(2, "speed", "Avg Speed", "city/sensor2/data", "km/h", 25.4378, -100.9760, 48, 22, "#4ec9b0"),
    Sensor(3, "congestion", "Congestion", "city/sensor3/data", "index", 25.4290, -100.9870, 0, 0, "#d64545", True),
    Sensor(5, "parking", "Parking Occ.", "city/sensor5/data", "%", 25.4525, -101.0125, 65, 30, "#9d7cd8"),
    Sensor(6, "pedestrian", "Pedestrian", "city/sensor6/data", "ppl/min", 25.4220, -100.9650, 22, 18, "#6dca7a"),
    Sensor(8, "heavy", "Heavy Vehicles", "city/sensor8/data", "trk/hr", 25.4550, -100.9450, 14, 12, "#e8c547"),
]
SENSOR_BY_ID = {s.id: s for s in SENSORS}
SENSOR_BY_KEY = {s.key: s for s in SENSORS}
SENSOR_CENTROID = (25.4385, -100.9787)          # (lat, lng)
SALTILLO_CENTER = (25.4385, -100.9787)
ODESSA_CENTER = (31.8457, -102.3676)

# (dLng, dLat, width m, depth m, height m) — extruded in the Cesium scene
BUILDINGS = [
    (-0.002, 0.004, 55, 42, 190), (0.004, 0.002, 42, 36, 260), (-0.006, -0.002, 62, 52, 130),
    (0.007, 0.005, 34, 34, 340), (0.001, -0.006, 50, 44, 210), (-0.009, 0.006, 38, 30, 155),
    (0.010, -0.003, 30, 30, 290), (-0.004, -0.008, 68, 54, 98), (0.002, 0.009, 26, 26, 370),
    (-0.012, -0.001, 44, 38, 170),
]


# --------------------------------------------------------------------------- Odessa field sensors
def generate_odessa_sensors(n: int = 50) -> list[dict]:
    """Deterministic placement (same LCG as the JS, so positions are stable)."""
    seed = 1337

    def rng() -> float:
        nonlocal seed
        seed = (seed * 9301 + 49297) % 233280
        return seed / 233280

    keys = [s.key for s in SENSORS]
    out = []
    for i in range(n):
        tight = rng() < 0.55                         # downtown cluster vs city limits
        radius = 0.018 if tight else 0.055
        angle = rng() * math.pi * 2
        r = radius * math.sqrt(rng())
        lat = ODESSA_CENTER[0] + r * math.cos(angle)
        lng = ODESSA_CENTER[1] + r * math.sin(angle)
        typ = keys[int(rng() * len(keys))]
        s = SENSOR_BY_KEY[typ]
        threshold = s.baseline + (rng() - 0.5) * (s.range or 1) * 1.2
        out.append(dict(id=f"OD-{i + 1:02d}", lat=lat, lng=lng, type=typ, threshold=round(threshold, 2)))
    return out


ODESSA_SENSORS = generate_odessa_sensors()


# --------------------------------------------------------------------------- mesh simulation
@dataclass
class Reading:
    value: float
    history: list[float]
    delta: float = 0.0


@dataclass
class SensorMesh:
    seed: int = 2101
    now: datetime = field(default_factory=lambda: datetime(2026, 1, 1, 12, 0, 0))
    readings: dict[int, Reading] = field(init=False)
    events: list[dict] = field(default_factory=list)
    _walk: dict[int, float] = field(init=False)
    _eid: int = 0

    def __post_init__(self):
        self.rng = random.Random(self.seed)
        self.readings = {s.id: Reading(s.baseline, [s.baseline] * HISTORY_LEN) for s in SENSORS}
        self._walk = {s.id: s.baseline for s in SENSORS}

    def _emit(self, sensor: Sensor, value: float) -> None:
        self._eid += 1
        self.events.insert(0, dict(id=self._eid, ts=self.now, topic=sensor.topic,
                                   payload={"sensor": sensor.key, "value": value}))
        del self.events[EVENT_LIMIT:]

    def _publish(self, sensor: Sensor, value: float) -> None:
        old = self.readings[sensor.id]
        self.readings[sensor.id] = Reading(value, (old.history + [value])[-HISTORY_LEN:], value - old.value)
        self._emit(sensor, value)

    def step(self, dt_s: float = 1.0) -> None:
        """Advance the mesh by ``dt_s`` seconds: every non-derived sensor publishes one
        random-walk sample (mean-reverting), then congestion = flow / (speed + 1)."""
        self.now += timedelta(seconds=dt_s)
        for s in SENSORS:
            if s.derived:
                continue
            noise = (self.rng.random() - 0.5) * s.range * 0.4
            pull = (s.baseline - self._walk[s.id]) * 0.18
            self._walk[s.id] = max(0.0, self._walk[s.id] + noise + pull)
            self._publish(s, round(self._walk[s.id], 1))
        flow = self.readings[1].value
        speed = self.readings[2].value
        self._publish(SENSOR_BY_ID[3], round(flow / (speed + 1), 2))

    def run(self, steps: int) -> "SensorMesh":
        for _ in range(steps):
            self.step()
        return self

    # -- derived views --------------------------------------------------------------
    def gateway_health(self, window_s: float = 5.0) -> dict:
        recent = [e for e in self.events if (self.now - e["ts"]).total_seconds() < window_s]
        n = len(recent)
        return dict(
            service="FastAPI", rate=round(n / window_s, 1), sensors_up=f"{len(SENSORS)} / {len(SENSORS)}",
            cpu=min(100, 18 + n * 1.4), mem=32 + (self.readings[1].value / 100) * 12, net=min(100, 8 + n * 2),
        )

    def odessa_state(self) -> list[dict]:
        """Each field sensor is ON when its type's live value exceeds its threshold."""
        out = []
        for s in ODESSA_SENSORS:
            value = self.readings[SENSOR_BY_KEY[s["type"]].id].value
            out.append({**s, "value": value, "on": value > s["threshold"]})
        return out

    def odessa_stats(self) -> dict:
        state = self.odessa_state()
        by_type = {s.key: {"active": 0, "total": 0} for s in SENSORS}
        for s in state:
            by_type[s["type"]]["total"] += 1
            by_type[s["type"]]["active"] += int(s["on"])
        return dict(active=sum(s["on"] for s in state), total=len(state), by_type=by_type)
