import streamlit as st

from smartcity import figures as F
from smartcity import robot_arm, ui

ui.setup("Brazo Mecánico — Vector 3D · Cinemática", "Quaternions · slerp · cubic easing",
         "Pick-and-place state machine: idle → aiming → dipping → grabbed → lifting → returning", icon="🦾")

with st.sidebar:
    seed = st.number_input("Seed", 0, 9999, 7)
    rot = st.slider("Idle rotation speed (rad/s)", 0.0, 1.0, 0.35, 0.05)
    freq = st.slider("Pick frequency", 0.0, 1.0, 0.55, 0.05)
    duration = st.slider("Animation length (s)", 6, 30, 12)
    fps = st.select_slider("Frames per second", [10, 15, 20], value=15)
    wire = st.toggle("Wireframe", True)


@st.cache_data(show_spinner="Simulating…")
def build(seed, rot, freq, duration, fps):
    return robot_arm.record_animation(duration, fps, seed=seed, rot_speed=rot, pick_freq=freq)


frames, edges, faces, ground_y = build(seed, rot, freq, duration, fps)
st.plotly_chart(F.arm_figure(frames, edges, faces, ground_y, wire, fps), use_container_width=True)
st.caption("Press ▶ Play. Rotation uses quaternion integration (no gimbal lock), smooth angular acceleration, "
           "slerp between orientations and a cubic ease-in-out per move. Amber diamonds are the screws.")
last = frames[-1]
c = st.columns(3)
c[0].metric("Final state", robot_arm.STATUS_ES[last["state"]])
c[1].metric("Screws picked", last["picked"])
c[2].metric("Frames", len(frames))
