"""Static editorial content ported from the original Jinja2 templates
(overview.html, article.html, sensors.html)."""

from __future__ import annotations

OVERVIEW_INTRO = (
    "IoT sensors are the nervous system of the modern city. Smart cities run on dense "
    "networks of distributed sensors that translate physical phenomena (air, traffic, "
    "water, vibration, light) into the digital signals that power every downstream urban "
    "service. This site breaks down what they measure, how they communicate, and where "
    "the technology is heading next."
)

OVERVIEW_STATS = [
    ("70%", "of the world's population is projected to live in cities by 2050.", "UN · World Urbanization Prospects"),
    ("20–40%", "reduction in intersection delay from adaptive traffic signaling driven by inline sensors.", "Field deployments · multiple cities"),
    ("50–70%", "lighting-energy savings from smart streetlights that dim based on real-time presence.", "EU · Smart Lighting trials"),
]

TELEMETRY_PREVIEW = [
    ("ENVIRONMENT", "Air Quality", "PM2.5, PM10, NO₂, O₃, temperature, humidity, ambient noise — sampled every 30s.", "topic/env/air"),
    ("MOBILITY", "Traffic Flow", "Vehicle counts, average speed, occupancy, pedestrian crossings via inductive loops & vision.", "topic/traffic/flow"),
    ("INFRASTRUCTURE", "Asset Health", "Vibration, strain, leak detection on bridges, tunnels, and water mains.", "topic/asset/health"),
    ("UTILITY", "Energy & Water", "Smart meter readings, demand-response signals, leak alerts from acoustic sensors.", "topic/utility/*"),
    ("OPERATIONS", "Waste & Lighting", "Bin fill levels, adaptive streetlight dimming, photocell presence detection.", "topic/ops/*"),
    ("PUBLIC SAFETY", "Acoustic & Edge CV", "Gunshot triangulation, anonymous crowd density, emergency vehicle preemption.", "topic/safety/*"),
]

SENSOR_FAMILIES = [
    {"n": "01", "name": "Environmental", "topic": "env / air-quality",
     "desc": "Continuous atmospheric monitoring across the city. Feeds real-time exposure maps, public-health dashboards, and low-emission-zone enforcement.",
     "tags": ["PM2.5", "PM10", "NO₂", "O₃", "temp", "humidity", "noise dB"], "meta": ("Sample rate", "30 s · 1 min")},
    {"n": "02", "name": "Mobility", "topic": "traffic / pedestrian",
     "desc": "Vehicle counts, speeds, and pedestrian flow data drive adaptive signaling, smart parking, and congestion modeling. Computer vision increasingly replaces aging loop detectors.",
     "tags": ["induction loops", "radar", "CV cameras", "BT/Wi-Fi probes", "lidar"], "meta": ("Latency target", "< 250 ms")},
    {"n": "03", "name": "Infrastructure", "topic": "structural / asset",
     "desc": "Embedded in bridges, tunnels, water mains, and streetlights to detect vibration, strain, corrosion, leaks, and outages before they become catastrophic failures.",
     "tags": ["accelerometers", "strain gauges", "acoustic emission", "fiber optic", "tilt"], "meta": ("Mode", "Predictive maintenance")},
    {"n": "04", "name": "Utility Metering", "topic": "electric / gas / water",
     "desc": "Smart meters and acoustic-pressure leak sensors enable demand-response programs, dynamic pricing, and water-loss reductions. Acoustic leak-finding turns weeks-long surveys into hours.",
     "tags": ["AMI", "flow", "pressure", "acoustic leak", "CT clamps"], "meta": ("Cadence", "15-min interval reads")},
    {"n": "05", "name": "Operations", "topic": "waste / lighting",
     "desc": "Fill-level sensors on waste bins optimize collection routes; smart streetlights dim adaptively, doubling as environmental probes, gunshot detectors, and 5G small-cell hosts.",
     "tags": ["ultrasonic fill", "PIR presence", "photocell", "5G mount"], "meta": ("Energy savings", "50–70%")},
    {"n": "06", "name": "Public Safety", "topic": "acoustic / video",
     "desc": "Gunshot acoustic triangulation, anonymous crowd-density estimation, and emergency-vehicle preemption. Privacy-preserving design uses on-device processing instead of raw video uplink.",
     "tags": ["acoustic array", "edge CV", "on-device anonymization"], "meta": ("Privacy", "Edge-only inference")},
]

COMM_STACK = [
    ("L1 · Edge", "Battery-powered sensor nodes with on-device filtering and TinyML inference", "microcontroller · I²C · SPI"),
    ("L2 · Network", "Long-range, low-power links sized for small payloads and multi-year battery life", "LoRaWAN · NB-IoT · LTE-M · 5G"),
    ("L3 · Gateway", "Edge aggregation, protocol translation, local rules, and burst buffering", "MQTT · CoAP · gRPC"),
    ("L4 · Platform", "Time-series storage, normalization, and unified APIs for downstream consumers", "FIWARE NGSI-LD · OGC SensorThings · TSDB"),
    ("L5 · Twin", "Live 3D digital twins, AI anomaly detection, predictive maintenance, dashboards", "Plotly · Streamlit · ML pipelines"),
]

ARTICLE_MD = """Research · IoT Infrastructure

# IoT Sensors for Smart Cities

*3 min read · 648 words · May 2026 · Topic: Urban IoT*

Smart cities rely on dense networks of **Internet of Things (IoT) sensors** to transform urban environments into data-driven ecosystems. These low-cost, distributed devices continuously capture information about traffic, air quality, energy use, and infrastructure health, feeding analytics platforms that help municipalities make faster, evidence-based decisions. As urbanization accelerates — projected to bring nearly **70% of the world's population** into cities by 2050 — IoT sensors have become foundational to sustainable, efficient, and livable urban environments. They are the nervous system of the modern city, translating physical phenomena into the digital signals that power every downstream service.

## Core Sensor Categories

Smart city deployments typically combine several sensor families. **Environmental sensors** monitor particulate matter (*PM2.5*, *PM10*), nitrogen dioxide, ozone, temperature, humidity, and noise, producing real-time exposure maps that inform health alerts and traffic restrictions. **Mobility sensors** — including inductive loops, radar units, computer vision cameras, and Bluetooth/Wi-Fi probes — track vehicle counts, speeds, and pedestrian flows. **Infrastructure sensors** embedded in bridges, tunnels, water mains, and streetlights detect vibration, strain, leaks, and outages before they become critical failures. **Utility sensors** metering electricity, gas, and water enable demand-response programs and rapid anomaly detection, while waste-bin fill-level sensors optimize collection routes and reduce operating costs.

## Communication and Architecture

Sensor data travels through layered architectures designed for scale and resilience. At the edge, low-power wide-area networks (*LPWAN*) such as *LoRaWAN*, *NB-IoT*, and *LTE-M* move small payloads over long distances on battery power lasting years. Higher-bandwidth nodes — video cameras, lidar units — use 5G or fiber backhaul. Edge gateways perform local preprocessing, filtering noise and running lightweight machine-learning inference to reduce upstream traffic and latency. Aggregated data then flows to fog or cloud platforms where it is normalized, stored in time-series databases, and exposed through APIs to municipal dashboards and third-party applications.

## Real-World Applications

Adaptive traffic signaling driven by inline sensors can cut intersection delays by 20–40%, lowering emissions and fuel use. Smart parking systems guide drivers directly to open spaces, reducing the cruising traffic that accounts for up to 30% of downtown congestion in some cities. Air-quality networks in **Barcelona**, **Seoul**, and **London** inform low-emission zone enforcement and public health advisories.

50–70% Smart streetlights dim dynamically based on pedestrian and vehicle presence, saving lighting energy while doubling as environmental probes and 5G small-cell hosts.

Water utilities use acoustic and pressure sensors to find leaks within hours rather than weeks, conserving millions of gallons annually.

## Data Integration and Digital Twins

The real value emerges when heterogeneous sensor streams converge in unified platforms. Modern smart-city stacks use open standards such as *FIWARE NGSI-LD*, *MQTT*, and *OGC SensorThings* to break vendor silos. Many cities now build **digital twins** — live 3D replicas of urban environments fed by real-time IoT data — to simulate policies, model emergencies, and coordinate departments. AI layered on top performs anomaly detection, predictive maintenance, and demand forecasting, turning raw measurements into actionable foresight.

## Challenges

Deploying citywide sensor networks raises significant challenges. **Cybersecurity** is paramount: each sensor is a potential attack surface, requiring secure boot, encrypted communications, and ongoing firmware updates. **Privacy** concerns demand careful design, especially for cameras and Wi-Fi probes that could enable surveillance; techniques like on-device anonymization and edge processing help mitigate risk. Interoperability between proprietary systems remains a persistent hurdle, as does long-term maintenance — sensors fail, batteries die, and calibration drifts. Equitable deployment is equally critical so that data-driven services do not bypass underserved neighborhoods or widen existing digital divides.

## Looking Ahead

The next generation of smart-city sensors will be smaller, cheaper, and increasingly autonomous. **Energy-harvesting** designs that draw power from solar, vibration, or RF ambient sources will eliminate battery replacements. **TinyML** models running directly on microcontrollers will enable sophisticated local decisions without cloud round-trips. Combined with 5G, satellite IoT, and mature digital-twin platforms, these advances will let cities respond to events in seconds rather than days — making urban life safer, greener, healthier, and far more responsive to the people who live in it.
"""
