import streamlit as st

from smartcity import figures as F
from smartcity import rpi_monitor as rpi
from smartcity import ui

ui.setup("RPi Linux Monitor", "3D Breadboard Simulation",
         "Raspberry Pi 4 + I²C sensor modules + 8 GPIO LEDs — telemetry mirrors linux_monitor.py", icon="🔌")

if "pi" not in st.session_state:
    st.session_state.pi = rpi.PiMonitor()
pi: rpi.PiMonitor = st.session_state.pi

with st.sidebar:
    live = st.toggle("Live (5 s cycle every 2 s)", value=True)
    if st.button("Advance one cycle"):
        pi.tick()
    wires = st.checkbox("Show wires", True)


def panel():
    if live:
        pi.tick()
    s = pi.snapshot()
    left, right = st.columns([3, 2])
    with left:
        st.plotly_chart(F.board_figure(pi.gpio, wires), use_container_width=True)
    with right:
        g = st.columns(2)
        g[0].plotly_chart(F.gauge(s["cpu"], "CPU", "%"), use_container_width=True)
        g[1].plotly_chart(F.gauge(s["temp"], "SoC temp", "°C", 85, F.AMBER if s["temp"] > 55 else F.ACCENT), use_container_width=True)
        m = st.columns(3)
        m[0].metric("Freq", f"{s['freq']} MHz")
        m[1].metric("Memory", f"{s['mem_used']} / {pi.mem_total} MB", f"{s['mem_pct']:.0f}%", delta_color="off")
        m[2].metric("Disk", f"{s['disk_pct']:.1f} %")
        m = st.columns(3)
        m[0].metric("Load avg", f"{s['load1']:.2f}", f"{s['load5']:.2f} · {s['load15']:.2f}", delta_color="off")
        m[1].metric("Net ↓/↑", f"{s['rx_kbs']:.1f}/{s['tx_kbs']:.1f} KB/s")
        m[2].metric("Wi-Fi", f"{s['signal_dbm']} dBm")
        st.caption(f"Uptime {rpi.fmt_uptime(pi.uptime_sec)} · cycle {pi.cycle} · thermal: {rpi.temp_band(pi.temp)}")
    g1, g2, g3 = st.columns(3)
    with g1:
        st.markdown("**GPIO**")
        st.write(" ".join(f"{'🟢' if v else '⚫'} {p}" for p, v in zip(rpi.GPIO_PINS, pi.gpio)))
    with g2:
        st.markdown("**I²C bus**")
        for addr, name in rpi.I2C_DEVICES:
            st.write(f"✅ `{addr}` {name}")
    with g3:
        st.markdown("**systemd services**")
        for sv in pi.services:
            st.write(f"{'🟢' if sv['active'] else '🔴'} {sv['name']} · {sv['sub']} · pid {sv['pid']}")


st.fragment(run_every="2s" if live else None)(panel)()
